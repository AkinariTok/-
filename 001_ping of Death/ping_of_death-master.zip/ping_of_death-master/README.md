# Ping of Death Attack script

## Usage

First, use pcap_generator.py for generate the pcap file if you haven't one and then use flooder_pcap.py for do the attack.
