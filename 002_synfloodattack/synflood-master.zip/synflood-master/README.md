# synflood
SYN Flood DoS tool
> Usage
``
python synflood.py target port threads
``
